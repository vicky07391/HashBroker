package com.mattstine.cf.haash.repository;

import com.mattstine.cf.haash.model.Service;
import org.springframework.data.repository.CrudRepository;

public interface ServiceRepository extends CrudRepository<Service, String> {
}
