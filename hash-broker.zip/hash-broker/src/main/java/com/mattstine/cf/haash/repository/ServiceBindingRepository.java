package com.mattstine.cf.haash.repository;

import com.mattstine.cf.haash.model.ServiceBinding;
import org.springframework.data.repository.CrudRepository;

public interface ServiceBindingRepository extends CrudRepository<ServiceBinding,String> {
}
